export { default } from './Post'
