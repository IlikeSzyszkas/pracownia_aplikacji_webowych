export { default } from './Posts'
